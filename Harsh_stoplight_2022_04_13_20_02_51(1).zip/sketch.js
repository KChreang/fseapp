//Declare 'ding' sound effect
let ding
let select
//preload
function preload(){
  ding = loadSound("ding.mp3")
  select = loadSound("select.mp3")
}

  



let MENU = 0;
//these variables are for the hit the target game
var x = 250;
var y = 300;
var d = 40;
var targetx = 300;
var targety = 300;
var score2 = 0;

//these variables are for the collect the cookies game
var ballx = 300;
var bally = 300;
var ballSize = 40;
var score1 = 0;

//these variables are for the Color Matching game
var score3=0;

function setup() {
  createCanvas(500, 600);
}

function draw() {
  print(mouseX, mouseY)
  background(135,206,235);
  
  //App Name Box
  noStroke();
  fill(173,216,230);
  ellipse(250,100,200,100);
  fill(0,0,0);
  textFont('Comic Sans MS');
  textSize(32);
  text("APP NAME", 170, 110);
  
  //START BUTTON
  fill(173,216,230);
  ellipse(150,300,200,100);
  fill(0,0,0);
  textFont('Comic Sans MS');
  textSize(35);
  text("Start", 100, 310);
  
  //settings box
  fill(173,216,230);
  ellipse(370,300,200,100);
  fill(0,0,0);
  textFont('Comic Sans MS');
  textSize(32);
  text("Settings", 310, 310);
  
  //bubbles
  fill(172,216,230);
  ellipse(120,190,30,20);
  ellipse(40,600,60,70);
  ellipse(80,80,30,40);
  ellipse(300,400,80,40);
  ellipse(300,10,40, 20);
  ellipse(300,600,20,23);
  ellipse(80,80,30,40);
  ellipse(200,500,80,40);
  ellipse(400,450,10,40);
  ellipse(80,390,20,20);

  
  //MENU 1 (GAMES SELECTION)
  if (MENU == 1) {
    background(135,206,235)
    stroke(0);
    
    //GAME#1 BUTTON
    fill(173,216,230);
    rect(50, 100, 150, 150);
    fill(0);
    textSize(20)
    text('Collect the', 70, 160)
    text('Cookies', 85, 200)
    
    //GAME#2 BUTTON
    fill(173,216,230);
    rect(280, 100, 150, 150);
    fill(0);
    textSize(20)
    text('Match the', 305, 160)
    text('Shapes', 315, 200)
    
    //GAME#3 BUTTON
    fill(173,216,230);
    rect(50, 350, 150, 150);
    fill(0);
    textSize(20)
    text('Color', 100, 415)
    text('Matching', 80, 450)
    
    //GAME #4 BUTTON
    fill(173,216,230);
    rect(280, 350, 150, 150)
    fill(0);
    textSize(20)
    text('Hit the', 320, 420)
    text('Target', 320, 450)
    
    //BACK BUTTON FUNCTION
    fill(173,216,230);
    rect(375, 15, 110, 40)
    fill(0);
    textSize(30)
    text('Back', 390, 45)
  }  

//MENU 2 (SETTINGS)
if (MENU == 2) {
  background(135,206,235)
  textSize(30)
  fill(0);
  text('Settings go here', 140, 180)
  stroke(0);
  
  //BACK BUTTON FUNCTION
    fill(173,216,230);
    rect(375, 15, 110, 40)
    fill(0);
    textSize(30)
    text('Back', 390, 45)
}
  
  
  
//GAME #1 FUNCTIONS(COLLECT THE COOKIES)
if (MENU == 3) {

 background(135,206,235)
  textSize(30)
  fill(0);
  levelOne();
  text (("Score : " + score1), width/2, 580);
  stroke(0);


function levelOne(){
  text ("Grab The Cookies!", width-400, height-540);
  text ("Collect 10 to win!", width-400, height-500);
  text ("(Hover over black dot)", width-430, height-460);

  var distToBall = dist(ballx, bally, mouseX, mouseY);

  if (distToBall < ballSize/2) {
    ballx = random(width);
    bally = random(height);
    score1 = score1 + 1;
    if(ding.isPlaying() == false){
        ding.play()
      }
  }

  if (score1 >= 10) {
  text (("Good Job You Win!"), width-380, height-250);
}

  ellipse (ballx, bally, ballSize)
}
   
  
  //BACK BUTTON FUNCTION
    fill(173,216,230);
    rect(375, 15, 110, 40)
    fill(0);
    textSize(30)
    text('Back', 390, 45)
}
  
  
  
//GAME #2 FUNCTIONS(Match the Shapes)
  if (MENU == 4) {
  background(135,206,235)
  textSize(30)
  fill(0);
  text('Match the Shapes game', 80, 180)
    text('goes here', 170, 220)
  stroke(0);
  
  //BACK BUTTON FUNCTION
    fill(173,216,230);
    rect(375, 15, 110, 40)
    fill(0);
    textSize(30)
    text('Back', 390, 45)
}
  
  
  
  //GAME #3 FUNCTIONS (COLOR MATCHING)
  if (MENU == 5) {
  
  background(135,206,235)
  textSize(30)
  fill(0);
  text('Choose the color red', 100, 90)
  text('(Hover over the choice)', 80, 135)
  
  stroke(0);
  fill(255, 0, 0);
  rect(80, 170, 150, 150); // red box
  fill(0, 255, 0);
  rect(280, 170, 150, 150); // green box
  fill(0, 0, 255);
  rect(80, 370, 150, 150); // blue box
  fill(255);
  rect(280, 370, 150, 150); // white box
    
   if (mouseX > 60 && mouseX < 220 && mouseY > 170 && mouseY < 300) {
    score3 = score3 + 1;
    if(ding.isPlaying() == false){
        ding.play()
      }
     }
    if (0<score3) {
    fill(0);
    text (("You Win!"), 200, 350);
    }
  
  //BACK BUTTON FUNCTION
    fill(173,216,230);
    rect(375, 15, 110, 40)
    fill(0);
    textSize(30)
    text('Back', 390, 45)
}
  
  
  
  //GAME #4 FUNCTIONS (Hit the Target)
  if (MENU == 6) {
 
  background(135,206,235)
  textSize(30)
  fill(0);
  text('Hit the square', 140, 80)
  text('Get 5 to win!', 150, 120)
  text('(Move with arrow keys', 87, 160)
  text('and over the square)', 100, 210)
  stroke(0);
  
  if (keyIsPressed){
    if(keyCode == LEFT_ARROW){
      x = x - 3;
    }
    else if(keyCode == RIGHT_ARROW){
      x = x + 3;
    }
    else if(keyCode == UP_ARROW){
      y = y - 3;
    }
    else if(keyCode == DOWN_ARROW){
      y = y + 3;
    }
    
  if (x+(d/2) >= width || x-(d/2) == 0){
    x = 250;
    y = 300;
  }
  if (y+(d/2) >= height || y-(d/2) == 0){
    x = 250;
    y = 300;
  }
  
  }  
  
  fill(150,150,150);
  ellipse(x,y,d,d)
  square(targetx, targety, 40)
  
  levelOne();
  
  function levelOne(){
    fill(0);
    text("Score: " + score2, width/2, height - 15)
    var distToBall = dist(targetx, targety, x, y);
    if (distToBall < 40){
      targetx = random(width);
      targety = random(height);
      score2 = score2 + 1;
      if(ding.isPlaying() == false){
        ding.play()
      }
      
    }
    if (score2 >= 5) {
  text (("Good Job You Win!"), width-380, height-250);
}
    
  }
  
  //BACK BUTTON FUNCTION
    fill(173,216,230);
    rect(375, 15, 110, 40)
    fill(0);
    textSize(30)
    text('Back', 390, 45)
}
  
}
  



//ALL FUNCTIONS BELOW ARE INTERACTIVE BUTTON FUNCTIONS (BASICALLY ALL THE BUTTONS FOR THE MENUS AND STUFF)

function mouseClicked() {
  //MENU 0 BUTTON FUNCTIONS
  if (MENU == 0) {
    if (mouseX > 50 && mouseX < 250 && mouseY > 250 && mouseY < 350) {
        MENU = 1;
        if(select.isPlaying() == false){
        select.play()
      }
      }
    
      else if (mouseX > 300 && mouseX < 500 && mouseY > 250 && mouseY < 350){
        MENU = 2;
        if(select.isPlaying() == false){
        select.play()
      }
      }
    }
  
  
  //MENU 1 BUTTON FUNCTIONS
  if (MENU == 1) {
    if (mouseX > 380 && mouseX < 500 && mouseY > 20 && mouseY < 60) {
        MENU = 0;
        if(select.isPlaying() == false){
        select.play()
      }
      }  
    else if (mouseX > 50 && mouseX < 200 && mouseY > 100 && mouseY < 250){
        MENU = 3;
        if(select.isPlaying() == false){
        select.play()
      }
      }
    else if (mouseX > 300 && mouseX < 430 && mouseY > 100 && mouseY < 250){
        MENU = 4;
        if(select.isPlaying() == false){
        select.play()
      }
      }
    else if (mouseX > 50 && mouseX < 200 && mouseY > 350 && mouseY < 500){
        MENU = 5;
        if(select.isPlaying() == false){
        select.play()
      }
      }
    else if (mouseX > 300 && mouseX < 430 && mouseY > 350 && mouseY < 500){
        MENU = 6;
        if(select.isPlaying() == false){
        select.play()
      }
      }
  }  
  
  
  //MENU 2 BUTTON FUNCTIONS
  if (MENU == 2) {
    if (mouseX > 380 && mouseX < 500 && mouseY > 20 && mouseY < 60) {
        MENU = 0;
        if(select.isPlaying() == false){
        select.play()
      }
      }  
    }
  
  //MENU 3 BUTTON FUNCTIONS
  if (MENU == 3) {
    if (mouseX > 380 && mouseX < 500 && mouseY > 20 && mouseY < 60) {
        MENU = 1;
        if(select.isPlaying() == false){
        select.play()
      }
      }  
    }
  
  //MENU 4 BUTTON FUNCTIONS
  if (MENU == 4) {
    if (mouseX > 380 && mouseX < 500 && mouseY > 20 && mouseY < 60) {
        MENU = 1;
        if(select.isPlaying() == false){
        select.play()
      }
      }  
    }
  
  //MENU 5 BUTTON FUNCTIONS
  if (MENU == 5) {
    if (mouseX > 380 && mouseX < 500 && mouseY > 20 && mouseY < 60) {
        MENU = 1;
        if(select.isPlaying() == false){
        select.play()
      }
        score3=0;
      }    
    }
  
  //MENU 6 BUTTON FUNCTIONS
  if (MENU == 6) {
    if (mouseX > 380 && mouseX < 500 && mouseY > 20 && mouseY < 60) {
        MENU = 1;
        if(select.isPlaying() == false){
        select.play()
      }
      }  
  }
}


